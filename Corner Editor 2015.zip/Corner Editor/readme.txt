Version 1.0.6

Installation

Move "Corner Editor.jsx" to "/Presets/Scripts/" in the Photoshop directory.

The next time Photoshop is opened, you can run the script from "File -> Scripts -> Corner Editor"

For easier access, make an action or add a keyboard shortcut