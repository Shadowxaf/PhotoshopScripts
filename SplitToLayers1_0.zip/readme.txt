Installation

Move "Split to Layers.jsx" to "/Presets/Scripts/" in the Photoshop directory.

The next time Photoshop is opened, you can run the script from File->Scripts->Split to Layers.