Installation

Move Rounded_Rectangle_Radius_Resizer.jsx to Presets/Scripts/ in the Photoshop directory.

The next time Photoshop is opened, you can run the script from File->Scripts->Rounded_Rectangle_Radius_Resizer.